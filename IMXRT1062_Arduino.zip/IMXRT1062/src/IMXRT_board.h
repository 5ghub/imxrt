/*

  Copyright 2019, 5G HUB

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
  associated documentation files (the "Software"), to deal in the Software without restriction, including
  without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be included in all copies or substantial
  portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
  TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.

*/

#ifndef __IMXRT_BOARD_H_
#define __IMXRT_BOARD_H_

// LTE & IoT modems
 #include "IMXRT_Modem_Common.h"
 #include "IMXRT_ATCommand.h"
 #include "IMXRT_FILE.h"
 #include "IMXRT_GNSS.h"
 #include "IMXRT_HTTP.h"
 #include "IMXRT_MQTT.h"
 #include "IMXRT_Serial.h"
 #include "IMXRT_SSL.h"
 #include "IMXRT_TCPIP.h"
 #include "AWSIOT.hpp"

 #include "extRAM_t4.h"

 #include "5GHUB_Sensor.h"

// #include <utility/imumaths.h>

//BME680 sensor
 #include "5GHUB_BME680.h"

//TSL25911 sensor
 #include "5GHUB_TSL25911.h"

//BNO055 sensor
 #include "5GHUB_BNO055.h"

//Ultrasonic sensor 
 #include "SR04_5G.h"

//RAM
#include "extRAM_t4.h"


//USB2 interface
#include "USBHost_t36.h"

//u-blox GNSS
#include "u-blox_GNSS_Arduino_Library.h"

//Serial Flash
#include "SerialFlash.h"

#include "IMXRT_pindef.h"


#endif
