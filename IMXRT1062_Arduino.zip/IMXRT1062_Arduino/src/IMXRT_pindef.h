/*

  Copyright 2019, 5G HUB

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
  associated documentation files (the "Software"), to deal in the Software without restriction, including
  without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be included in all copies or substantial
  portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
  TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.

*/

#ifndef __IMXRT_PINDEF_H_
#define __IMXRT_PINDEF_H_

#define D0 0//GPIO_AD_B0_03
#define D1 34 //GPIO_AD_B0_02
#define D2 0//GPIO_EMC_04
#define D3 0//GPIO_EMC_05
#define D4 0//GPIO_EMC_06
#define D5 0//GPIO_EMC_08
//#define D6 
#define D7 0//GPIO_B1_01
#define D8 0//GPIO_B1_00
//#define D9 
#define D10 0//GPIO_B0_00

#define D11 0//GPIO_B0_02
#define D12 0//GPIO_B0_01
#define D13 33 //GPIO_B0_03
#define D14 28 //GPIO_AD_B1_02
#define D15 29 //GPIO_AD_B1_03
#define D16 19 //GPIO_AD_B1_07
#define D17 0//GPIO_AD_B1_06
#define D18 13 //GPIO_AD_B1_01
#define D19 12 //GPIO_AD_B1_00
#define D20 22 //GPIO_AD_B1_10

#define D21 23 //GPIO_AD_B1_11
#define D22 0//GPIO_AD_B1_08
#define D23 0//GPIO_AD_B1_09
#define D24 15 //GPIO_AD_B0_12
#define D25 14 //GPIO_AD_B0_13
#define D26 26 //GPIO_AD_B1_14
#define D27 27 //GPIO_AD_B1_15
#define D28 0//GPIO_EMC_32
#define D29 0//GPIO_EMC_31
#define D30 0//GPIO_EMC_37


#define D31 0//GPIO_EMC_36
//#define D32 
#define D33 0//GPIO_EMC_07
#define D34 0//GPIO_B1_13
#define D35 0//GPIO_B1_12
#define D36 0//GPIO_B1_02
#define D37 0//GPIO_B1_03 
#define D38 24 //GPIO_AD_B1_12
#define D39 25 //GPIO_AD_B1_13
#define D40 16 //GPIO_AD_B1_04
#define D41 17 //GPIO_AD_B1_05


#define USER_LED  			30 //GPIO_AD_B0_09
#define RESET_MCU_BUTTON 	POR_B
#define RESET_MDM_BUTTON


#define RESET_MDM  	  35
#define DISABLE_MDM   36
#define EP06_RESET 

#define SCL   D19
#define SDA   D18

#define SCK 
#define MISO 
#define MOSI 
#define SS 	 

//Define SD Card PINs


// Define Ethernet PINs

#endif
